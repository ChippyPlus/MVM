* MemoryRange \[a] \[b]
* Register 
* descriptors
* stack