work in progress?

* neg
* readln
* println
* inc
* dec