package internals.instructions.misc

open class Misc