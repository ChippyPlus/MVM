val r4Outs = setOf("add", "sub", "mul", "div", "mod", "strlen", "strcmp", "strcat", "lt", "gt")
val r3Outs = setOf("and", "or", "not", "xor", "shr", "shl")