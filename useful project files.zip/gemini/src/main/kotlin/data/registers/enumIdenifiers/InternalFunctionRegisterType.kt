package data.registers.enumIdenifiers

enum class InternalFunctionRegisterType {
	IF0, IF1, IF2, IF3, IF4, IF5, IF6, IF7, IF8, IF9
}