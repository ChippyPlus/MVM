package data.memory

@JvmInline
value class MemoryAddress(val address: Long?)