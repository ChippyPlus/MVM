package data.memory

@JvmInline
value class MemoryValue(val value: Long?)