package data.registers.enumIdenifiers

enum class ReturnRegisterType {
    R1,
    R2,
    R3,
    R4
}