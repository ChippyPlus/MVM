package data.registers.enumIdenifiers

enum class SystemRegisterType {
    S1,
    S2,
    S3,
    S4
}