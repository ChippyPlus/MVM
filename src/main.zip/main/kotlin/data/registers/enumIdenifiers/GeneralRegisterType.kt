package data.registers.enumIdenifiers

enum class GeneralRegisterType {
    G1,
    G2,
    G3,
    G4
}