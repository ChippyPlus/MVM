package internals.instructions.strings



open class Strings