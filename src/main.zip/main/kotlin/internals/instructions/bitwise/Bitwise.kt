package internals.instructions.bitwise



open class Bitwise