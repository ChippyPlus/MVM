package internals.instructions.memory



open class Memory