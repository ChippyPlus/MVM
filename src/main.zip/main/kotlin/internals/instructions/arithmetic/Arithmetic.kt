package internals.instructions.arithmetic



open class  Arithmetic