package debugger

enum class DebugInstructionModes {
    Line,
    Iterator
}