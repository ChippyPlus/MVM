package helpers

import java.io.File

data class VMFile(val file: File)
